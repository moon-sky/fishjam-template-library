#include "StdAfx.h"
//#include "SkinScrollBar.h"
#include "SkinComboBox.h"
#include <atlimage.h>
#include <ftlgdi.h>

const int EDIT_MARGIN_LEFT = 8;
const int EDIT_MARGIN_TOP = 5;

const int ARROW_MARGIN_TOP = 5;
const int ARROW_MARGIN_RIGHT = 4;
const int ARROW_MARGIN_BOTTOM = 5;
const int ARROW_WIDTH = 10;

const int MARGIN_TOP = 9;
const int MARGIN_BOTTOM = 12;
const int MARGIN_LEFT = 8;

const COLORREF COLOR_FOCUS_STOKE = RGB(0x3f, 0x86, 0xce);

CSkinComboBox::CSkinComboBox()
{
	m_nFontHeigth = 11;
	m_bOver = FALSE;
	m_hListBox = NULL;
	m_oldListBoxWinProc = NULL;
}

CSkinComboBox::~CSkinComboBox()
{

}

void CSkinComboBox::SetFont(HFONT hFont)
{
	FTLASSERT(hFont);

	m_hFont = hFont;
	CClientDC dc(m_hWnd);
	
	HFONT hOldFont = NULL;
	
	hOldFont = dc.SelectFont(hFont);
	TEXTMETRIC textMetrics = { 0 };
	dc.GetTextMetrics(&textMetrics);
	m_nFontHeigth = textMetrics.tmHeight;
	dc.SelectFont(hOldFont);
}

void CSkinComboBox::UpdateRect(void)
{
	CRect rcClient;
	GetWindowRect( &rcClient );
	rcClient.DeflateRect( -2,-2 );
	GetParent().ScreenToClient( &rcClient );
	GetParent().InvalidateRect( &rcClient,FALSE );
	return;
}

void CSkinComboBox::DrawEdit( UINT iState,CRect rcClient, HDC hDC, int itemID)
{
	
	CString strText;
	GetLBText(itemID, strText);

	CRect rcText = rcClient;
	//rcText.left += EDIT_MARGIN_LEFT;
	//rcText.top += EDIT_MARGIN_TOP;
	//rcText.right -= ( ARROW_MARGIN_RIGHT + ARROW_WIDTH );

	CDCHandle dc(hDC);
	dc.DrawText(strText, -1, rcText, DT_LEFT | DT_TOP );
	FTL::CFGdiUtil::DrawCoordinate(hDC, rcText, FALSE, TRUE);
	//dc.Rectangle()
}

void CSkinComboBox::DrawContent( UINT iState,CRect rcClient, HDC hDC,int itemID)
{

	CDCHandle dc(hDC);
	dc.SetBkMode( TRANSPARENT );

	//if (ODS_SELECTED & iState)
	//{
	//	//��ʱ����ѡ������
	//	UpdateRect();
	//}

	CString strText;
	GetLBText(itemID, strText);
	CRect rcText = rcClient;
	rcText.top += MARGIN_TOP;
	rcText.left += MARGIN_LEFT;
	
	CPen redPen;
	redPen.CreatePen(PS_SOLID, 1, RGB(0,0,255));
	HPEN hOldPen = NULL;
	if (iState & ODS_FOCUS)
	{
		dc.FillSolidRect(rcText, RGB(0,255,0));
	}
	if (iState & ODS_SELECTED)
	{
		hOldPen = dc.SelectPen(redPen);
	}
	dc.DrawText( strText,-1, &rcText, DT_TOP | DT_LEFT);

	if (NULL != hOldPen)
	{
		dc.SelectPen(hOldPen);
	}
	
	

	//if ( itemID == m_selItem )
	//{
	//	CPen bgPen;
	//	bgPen.CreatePen( PS_SOLID,1,RGB( 141,178,227 ) );
	//	CPen* pOldPen = pDC->SelectObject( &bgPen );
	//	CBrush* pOldBrush = pDC->SelectObject( m_pBrsh );
	//	pDC->RoundRect( &rcClient,CPoint( 5,5 ) );
	//	pDC->SelectObject( pOldBrush );
	//	pDC->SelectObject( pOldPen );
	//	bgPen.DeleteObject();
	//}
	////����һ��ͼ��
	//rcLeft.right = rcLeft.left + 16;
	//rcLeft.top += 4;
	//::DrawIconEx( pDC->m_hDC,rcLeft.left,rcLeft.top,pItem->hIcon,16,16,NULL,NULL,DI_NORMAL );

	////���ڶ����ı�
	//rcMid.left = rcLeft.right + 10;
	//rcMid.right = rcClient.right - 100;
	//pDC->SetTextColor( pItem->clrLeft );
	//CFont* pOldFont = pDC->SelectObject( &m_font );
	//pDC->DrawText( pItem->strUrl,&rcMid,DT_VCENTER|DT_LEFT|DT_SINGLELINE );

	////���������ı�
	//rcRight.left = rcMid.right + 8;
	//pDC->SetTextColor( pItem->clrRight );
	//pDC->DrawText( pItem->strTitle,&rcRight,DT_VCENTER|DT_LEFT|DT_SINGLELINE );
	//pDC->SelectObject( pOldFont );

	//CRect rcEnd( rcClient );
	//rcEnd.left = rcEnd.right - 18;
	//rcEnd.top += 3;
	//if ( itemID == m_selItem )
	//{
	//	if ( m_bFous )
	//	{
	//		DrawIconEx( pDC->m_hDC,rcEnd.left,rcEnd.top,AfxGetApp()->LoadIcon( IDI_ICON6 ),16,16,NULL,NULL,DI_NORMAL );
	//	}
	//	else
	//	{
	//		DrawIconEx( pDC->m_hDC,rcEnd.left,rcEnd.top,AfxGetApp()->LoadIcon( IDI_ICON7 ),16,16,NULL,NULL,DI_NORMAL );
	//	}

	//}
}

void CSkinComboBox::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	UINT itemID = lpDrawItemStruct->itemID;
	CRect rcClient = lpDrawItemStruct->rcItem;
	UINT  iState = lpDrawItemStruct->itemState;

	FTL::CFStringFormater formater;
	FTLTRACE(TEXT("DrawItem: itemId=%d, iState= 0x%x(%s)\n"),
		lpDrawItemStruct->itemID, iState,  FTL::CFWinUtil::GetOwnerDrawState(formater, iState));

	FTLASSERT(lpDrawItemStruct->CtlType == ODT_COMBOBOX);

	
	CDCHandle dc(lpDrawItemStruct->hDC);
	dc.SetBkMode( TRANSPARENT );

	if (ODS_COMBOBOXEDIT & iState)
	{
		DrawEdit(iState, rcClient,dc , itemID );
	}
	else
	{
		DrawContent( iState, rcClient, dc, itemID );
	}
	


	//CString strItem;
	////strItem.Format(TEXT("Item %d"), lpDrawItemStruct->itemID);



	//if (lpDrawItemStruct->itemID != -1)
	//{
	//	GetLBText(lpDrawItemStruct->itemID, strItem);
	//	//FTLASSERT(lpszText != NULL);

	//	// Save these value to restore them when done drawing.
	//	COLORREF crOldTextColor = dc.GetTextColor();
	//	COLORREF crOldBkColor = dc.GetBkColor();

	//	// If this item is selected, set the background color 
	//	// and the text color to appropriate values. Erase
	//	// the rect by filling it with the background color.
	//	if ((lpDrawItemStruct->itemAction & ODA_SELECT) &&
	//		(lpDrawItemStruct->itemState  & ODS_SELECTED))
	//	{
	//		dc.SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
	//		dc.SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
	//		dc.FillSolidRect(&lpDrawItemStruct->rcItem, ::GetSysColor(COLOR_HIGHLIGHT));
	//	}
	//	else
	//	{
	//		dc.FillSolidRect(&lpDrawItemStruct->rcItem, crOldBkColor);
	//	}

	//	// Draw the text.
	//	dc.DrawText(
	//		strItem,
	//		-1,
	//		&lpDrawItemStruct->rcItem,
	//		DT_CENTER|DT_SINGLELINE|DT_VCENTER);

	//	// Reset the background color and the text color back to their
	//	// original values.
	//	dc.SetTextColor(crOldTextColor);
	//	dc.SetBkColor(crOldBkColor);
	//}
	//


	////dc.Detach();

}

void CSkinComboBox::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	FTLTRACE(TEXT("MeasureItem: itemId=%d\n"), lpMeasureItemStruct->itemID);

	//if (lpMeasureItemStruct->itemID != (UINT) -1)
	//{
	//	LPCTSTR lpszText = (LPCTSTR) lpMeasureItemStruct->itemData;
	//	CSize   sz;
	//	CClientDC dc(m_hWnd);
	//	dc.GetTextExtent(lpszText, -1, &sz);
	//	lpMeasureItemStruct->itemHeight = 2*sz.cy;
	//}
	//else
	//{
	CRect rcClient;
	GetClientRect(rcClient);
	lpMeasureItemStruct->itemHeight = 30;// MARGIN_TOP + m_nFontHeigth + MARGIN_BOTTOM;
	lpMeasureItemStruct->itemWidth = rcClient.Width();
	//}

}

int  CSkinComboBox::CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct)
{
	FTLTRACE(TEXT("CompareItem: itemID1=%d, itemID2=%d\n"), lpCompareItemStruct->itemID1, lpCompareItemStruct->itemID2);
	return 0;
}

void CSkinComboBox::DeleteItem(LPDELETEITEMSTRUCT lpDeleteItemStruct)
{
	//FTLTRACE(TEXT("DeleteItem: itemId=%d\n"), lpDeleteItemStruct->itemID);
}

void CSkinComboBox::OnPaint(CDCHandle /*dc*/)
{
	FTLTRACE(TEXT("OnPaint\n"));
	CPaintDC dc(m_hWnd); // device context for painting
	
	CRect rcClient;
	GetClientRect(&rcClient);
	CMemoryDC memDC(dc, rcClient);
	memDC.Rectangle(rcClient);

	CRect rcArray = rcClient;
	rcArray.right -= ARROW_MARGIN_RIGHT;
	rcArray.left = rcArray.right - ARROW_WIDTH;
	rcArray.top = ARROW_MARGIN_TOP;
	rcArray.bottom -= ARROW_MARGIN_BOTTOM;

	memDC.FillSolidRect(rcArray, RGB(255,0,0));

	CRect rcText = rcClient;
	rcText.left += EDIT_MARGIN_LEFT;
	rcText.top += EDIT_MARGIN_TOP;
	
	DrawEdit(0 , rcText, memDC, GetCurSel());

	//DrawEdit(0, rc, dc, 0);

	//OnNcPaint( dc );
}

void CSkinComboBox::OnNcPaint( HDC hDC )
{
	//CRect rc;
	//GetClientRect(&rc);
	//DrawEdit(0, rc, hDC, 0);
	//return ;

	////���ƿͻ���
	//CDC dMemDC;
	//dMemDC.CreateCompatibleDC(hdc);
	////dMemDC.SetMapMode(pDC->GetMapMode());

	////������
	//CBitmap mNewBmp;
	//CRect rc;
	//GetClientRect(&rc);

	//mNewBmp.CreateCompatibleBitmap( hDC, rc.right - rc.left, rc.bottom - rc.top);
	//CBitmap hOldBmp = dMemDC.SelectBitmap(&mNewBmp);

	////CPen* pOldPen = dMemDC.SelectObject( &m_bgPen );
	////CBrush* pOldBrsh = dMemDC.SelectObject( m_bgBrush );
	////dMemDC.Rectangle( &rc );
	////dMemDC.SelectObject( pOldPen );
	////dMemDC.SelectObject( &pOldBrsh );

	//if ( (GetCurSel() > 4)||(GetCurSel() < 0) )
	//{
	//	return;
	//}

	//PItemList pItem = m_vecItemList[GetCurSel()];

	//CPen	m_penLeft;
	//CPen	m_penRight;
	//CRect rcLeft,rcMid,rcRight;
	//rcLeft = rcMid = rcRight = rc;
	//dMemDC.SetBkMode( TRANSPARENT );

	////����һ��ͼ��
	//rcLeft.right = rcLeft.left + 16;
	//rcLeft.left += 1;
	//rcLeft.top += 4;
	//::DrawIconEx( dMemDC.m_hDC,rcLeft.left,rcLeft.top,pItem->hIcon,16,16,NULL,NULL,DI_NORMAL );

	////���ڶ����ı�
	//rcMid.left = rcLeft.right + 10;
	//rcMid.right = rc.right - 110;
	//CFont* pOldFont = dMemDC.SelectObject( &m_font );
	//dMemDC.SetTextColor( pItem->clrLeft );
	//dMemDC.DrawText( pItem->strUrl,&rcMid,DT_VCENTER|DT_LEFT|DT_SINGLELINE );

	////���������ı�
	//rcRight.left = rcMid.right;
	//dMemDC.SetTextColor( pItem->clrRight );
	//dMemDC.DrawText( pItem->strTitle,&rcRight,DT_VCENTER|DT_LEFT|DT_SINGLELINE );
	//dMemDC.SelectObject( pOldFont );

	//CRect rcEnd(rc);
	//rcEnd.left = rc.right - 22;

	//if( m_bDown )
	//{
	//	dMemDC.DrawFrameControl( &rcEnd,DFC_SCROLL,DFCS_SCROLLDOWN|DFCS_FLAT|DFCS_MONO|DFCS_PUSHED );
	//}
	//else
	//{
	//	dMemDC.DrawFrameControl( &rcEnd,DFC_SCROLL,DFCS_SCROLLDOWN|DFCS_FLAT|DFCS_MONO );
	//}

	//pDC->BitBlt(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, &dMemDC,
	//	rc.left ,rc.top, SRCCOPY);

	////�ָ�
	//dMemDC.SelectObject(pOldBmp);
	//pOldBmp->DeleteObject();
	//dMemDC.DeleteDC();
}

BOOL CSkinComboBox::OnEraseBkgnd(CDCHandle dc)
{
	FTLTRACE(TEXT("OnEraseBkgnd\n"));
	return TRUE;
}
void CSkinComboBox::OnMouseMove(UINT nFlags, CPoint point)
{
	FTLTRACE(TEXT("OnMouseMove\n"));
	//if ( m_bOver == FALSE )
	//{
	//	m_bOver = TRUE;

	//	//���µ�ǰ����
	//	UpdateRect();

	//	TRACKMOUSEEVENT tme;
	//	tme.cbSize = sizeof( TRACKMOUSEEVENT );
	//	tme.dwFlags = TME_LEAVE;
	//	tme.dwHoverTime = 0;
	//	tme.hwndTrack = m_hWnd;

	//	_TrackMouseEvent( &tme );
	//}
	////CComboBox::OnMouseMove(nFlags, point);
	SetMsgHandled(FALSE);
}

void CSkinComboBox::OnMouseLeave()
{
	FTLTRACE(TEXT("OnMouseLeave\n"));
	if ( m_bOver )
	{
		m_bOver = FALSE;
	}
	UpdateRect();
	
}

LRESULT CALLBACK CSkinComboBox::ListBoxWindowProc(  HWND hwnd,   UINT uMsg,   WPARAM wParam, 
							LPARAM lParam )
{
	DUMP_WINDOWS_MSG(__FILE__LINE__, DEFAULT_DUMP_FILTER_MESSAGE, uMsg, wParam, lParam);
	CSkinComboBox* pCombox = (CSkinComboBox*)::GetWindowLongPtr(hwnd, GWLP_USERDATA);
	if (pCombox)
	{
		switch(uMsg)
		{
		case WM_DESTROY:
			::SetWindowLongPtr(hwnd, GWLP_USERDATA, NULL);
			::SetWindowLongPtr(hwnd, GWLP_WNDPROC, (LONG_PTR)(pCombox->m_oldListBoxWinProc));
			pCombox->m_hListBox = NULL;
			break;
		}
		return pCombox->m_oldListBoxWinProc(hwnd, uMsg, wParam, lParam);
	}
	return ::DefWindowProc(hwnd, uMsg, wParam, lParam);
}

HBRUSH CSkinComboBox::OnCtlColorListBox(CDCHandle dc, CListBox listBox)
{
	if (!m_hListBox)
	{
		m_hListBox = listBox.m_hWnd;
		LONG_PTR oldUserData = ::GetWindowLongPtr(m_hListBox, GWLP_USERDATA);
		FTLASSERT(NULL == oldUserData);
		
		m_oldListBoxWinProc = (WNDPROC)::GetWindowLongPtr(m_hListBox, GWLP_WNDPROC);
		::SetWindowLongPtr(m_hListBox, GWLP_USERDATA, (LONG_PTR) this);
		::SetWindowLongPtr(m_hListBox, GWLP_WNDPROC,( LONG_PTR)ListBoxWindowProc);
	}

	HBRUSH hBrush = (HBRUSH)DefWindowProc();
	FTLTRACE(TEXT("OnCtlColorListBox\n"));
	
	return hBrush;
}

void CSkinComboBox::OnLButtonDown(UINT nFlags, CPoint point)
{
	FTLTRACE(TEXT("OnLButtonDown\n"));
	DefWindowProc();
}
void CSkinComboBox::OnLButtonUp(UINT nFlags, CPoint point)
{
	FTLTRACE(TEXT("OnLButtonUp\n"));
	DefWindowProc();
}


//CSkinScrollWnd* SkinWndScroll(HWND hWnd, const SCROLLBAR_SKIN_INFO* m_pSkinInfo)
//{
//	CSkinScrollWnd* pNewFrame = new CSkinScrollWnd();
//	pNewFrame->Initialize(hWnd, *m_pSkinInfo);
//	pNewFrame->SendMessage ( WM_VSCROLL, MAKELONG ( SB_THUMBPOSITION, 0 ), ( LPARAM ) pNewFrame->m_hWnd );
//	pNewFrame->SendMessage ( WM_VSCROLL, SB_ENDSCROLL, ( LPARAM ) pNewFrame->m_hWnd );
//
//	return pNewFrame;
//}
//
//CSkinComboBox::CSkinComboBox ( void )
//{
//	m_hWndList = NULL;
//	m_pSkinInfo = NULL;
//}
//CSkinComboBox::~CSkinComboBox ( void )
//{
//
//}
//
//
//
//LRESULT CSkinComboBox::OnCbnDropDown(UINT uNotifyCode, int nID, CWindow wndCtl)
//{
//	if(!m_hWndList) 
//		return 0;
//	::ShowWindow(::GetParent(::GetParent(m_hWndList)),SW_HIDE);
//	return 0;
//}
//
//LRESULT CSkinComboBox::OnCbnCloseup(UINT uNotifyCode, int nID, CWindow wndCtl)
//{
//	if(!m_hWndList) return 0;
//	CWindow wndFrame (::GetParent(::GetParent(m_hWndList)));
//	CRect rc;
//	GetWindowRect(&rc);
//	CRect rc2;
//	this->GetDroppedControlRect(&rc2);
//	int nHei;
//	int nLineHei=GetItemHeight(0);
//	if(nLineHei*GetCount()<rc2.Height()-2)
//		nHei=nLineHei*GetCount()+2;
//	else
//		nHei=rc2.Height();
//	wndFrame.SetWindowPos(HWND_TOPMOST,rc.left,rc.bottom,rc2.Width(),nHei,0);
//	wndFrame.ShowWindow(SW_SHOW);
//
//	return 0;
//}
//
//HBRUSH CSkinComboBox::OnCtlColorListBox(CDCHandle dc, CListBox listBox)
//{
//	static HBRUSH hBrush = CreateSolidBrush(RGB(255,0,0));
//	if (!m_hWndList)
//	{
//		ShowWindow(SW_HIDE);
//		m_hWndList = listBox.m_hWnd;
//		SkinWndScroll(m_hWndList, m_pSkinInfo);
//	}
//	return hBrush;
//}
//BOOL CSkinComboBox::SkinScroll(const SCROLLBAR_SKIN_INFO* pSkinInfo)
//{
//	m_pSkinInfo = pSkinInfo;
//	ShowDropDown(TRUE);
//	ShowDropDown(FALSE);
//	return TRUE;
//}
//void CSkinComboBox::UnSkinScroll()
//{
//}
