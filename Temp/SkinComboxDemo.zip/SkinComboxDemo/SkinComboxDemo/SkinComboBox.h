#pragma once

//#include "SkinScrollWnd.h"

#include <ftlWindow.h>

class CSkinComboBox : public CWindowImpl<CSkinComboBox, CComboBox>,
	public COwnerDraw<CSkinComboBox>
{
public:
	CSkinComboBox(void);
	~CSkinComboBox(void);

	void SetFont(HFONT hFont);
	BEGIN_MSG_MAP_EX(CSkinComboBox)
		//DUMP_WINDOWS_MSG(__FILE__LINE__, 0, uMsg, wParam, lParam);
		MSG_WM_PAINT(OnPaint)
		MSG_WM_ERASEBKGND(OnEraseBkgnd)
		//MSG_WM_MOUSEMOVE(OnMouseMove)
		//MSG_WM_MOUSELEAVE(OnMouseLeave)
		MSG_WM_LBUTTONDOWN(OnLButtonDown)
		MSG_WM_LBUTTONUP(OnLButtonUp)
		//MESSAGE_HANDLER( CB_INSERTSTRING, OnInsertString )
		//MSG_OCM_CTLCOLOREDIT(OnReflectedCtlColorEdit)
		MSG_WM_CTLCOLORLISTBOX(OnCtlColorListBox)
		CHAIN_MSG_MAP_ALT(COwnerDraw<CSkinComboBox>, 1)
		DEFAULT_REFLECTION_HANDLER()
	END_MSG_MAP()

	void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	int  CompareItem(LPCOMPAREITEMSTRUCT lpCompareItemStruct);
	void DeleteItem(LPDELETEITEMSTRUCT lpDeleteItemStruct);

	void OnPaint(CDCHandle /*dc*/);
	BOOL OnEraseBkgnd(CDCHandle dc);
	void OnMouseMove(UINT nFlags, CPoint point);
	void OnMouseLeave();
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	HBRUSH OnReflectedCtlColorEdit(CDCHandle dc, CEdit edit);
	HBRUSH OnCtlColorListBox(CDCHandle dc, CListBox listBox);

private:
	BOOL	m_bOver;
	int		m_nFontHeigth;
	HFONT	m_hFont;
	HWND	m_hListBox;
	WNDPROC		m_oldListBoxWinProc;
	//int		m_nOldSelectItem;
	void DrawEdit(UINT iState,CRect rcClient, HDC hDC, int itemID);
	void DrawContent( UINT iState,CRect rcClient, HDC hDC, int itemID);
	void UpdateRect(void);
	void OnNcPaint( HDC hDC );
	static LRESULT CALLBACK ListBoxWindowProc(  HWND hwnd,   UINT uMsg,   WPARAM wParam, 
		LPARAM lParam );
};


//CSkinScrollWnd* SkinWndScroll(HWND hWnd, const SCROLLBAR_SKIN_INFO* m_pSkinInfo);
